# window-manager

Window management for BatchUV programs. Uses the native helper built into `batchuv.exe` (`--winctl`), so it needs no extra files and also works in exported EXEs.

| Command | Description |
|---|---|
| `settitle <text>` | Set the console window title |
| `resize <w> <h>` | Resize the window (pixels) |
| `move <x> <y>` | Move the window (screen pixels) |
| `center` | Center the window on its monitor |
| `minimize` / `maximize` / `restore` | Change window state |

Variables: `${window-manager.width}`, `.height`, `.x`, `.y` (window rectangle at `loadlib` time), plus `.name` and `.version`.

Works in classic conhost and Windows Terminal (it targets the owning top-level window).
